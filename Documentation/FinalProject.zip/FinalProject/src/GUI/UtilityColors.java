package GUI;

public class UtilityColors {

	public static String centuryOrange() {
		//Century Orange: R224, G82, B6
		return "#e05206";
	}

	public static String centuryBlue() {
		//Century Blue: R76, G119, B148
		return "#4C7794";
	}
}
